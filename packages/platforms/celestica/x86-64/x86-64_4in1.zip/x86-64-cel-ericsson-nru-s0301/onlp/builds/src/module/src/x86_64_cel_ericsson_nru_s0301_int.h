/**************************************************************************//**
 *
 * x86_64_cel_ericsson_nru_s0301 Internal Header
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_ERICSSON_NRU_S0301_INT_H__
#define __X86_64_CEL_ERICSSON_NRU_S0301_INT_H__

#include <x86_64_cel_ericsson_nru_s0301/x86_64_cel_ericsson_nru_s0301_config.h>

#endif /* __X86_64_CEL_ERICSSON_NRU_S0301_INT_H__ */