/**************************************************************************//**
 *
 * x86_64_cel_ericsson_nru_s0301 Doxygen Header
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_ERICSSON_NRU_S0301_DOX_H__
#define __X86_64_CEL_ERICSSON_NRU_S0301_DOX_H__

/**
 * @defgroup x86_64_cel_ericsson_nru_s0301 x86_64_cel_ericsson_nru_s0301 - x86_64_cel_ericsson_nru_s0301 Description
 *

The documentation overview for this module should go here.

 *
 * @{
 *
 * @defgroup x86_64_cel_ericsson_nru_s0301-x86_64_cel_ericsson_nru_s0301 Public Interface
 * @defgroup x86_64_cel_ericsson_nru_s0301-config Compile Time Configuration
 * @defgroup x86_64_cel_ericsson_nru_s0301-porting Porting Macros
 *
 * @}
 *
 */

#endif /* __X86_64_CEL_ERICSSON_NRU_S0301_DOX_H__ */
