/**************************************************************************//**
 *
 * 
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_ERICSSON_NRU_S0301_LOG_H__
#define __X86_64_CEL_ERICSSON_NRU_S0301_LOG_H__

#define AIM_LOG_MODULE_NAME x86_64_cel_ericsson_nru_s0301
#include <AIM/aim_log.h>

#endif /* __X86_64_CEL_ERICSSON_NRU_S0301_LOG_H__ */
