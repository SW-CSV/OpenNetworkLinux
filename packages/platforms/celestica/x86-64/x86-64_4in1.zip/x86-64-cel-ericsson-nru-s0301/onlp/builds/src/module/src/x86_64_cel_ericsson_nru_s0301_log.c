/**************************************************************************//**
 *
 *
 *
 *****************************************************************************/
#include <x86_64_cel_ericsson_nru_s0301/x86_64_cel_ericsson_nru_s0301_config.h>

#include "x86_64_cel_ericsson_nru_s0301_log.h"
/*
 * x86_64_cel_ericsson_nru_s0301 log struct.
 */
AIM_LOG_STRUCT_DEFINE(
                      X86_64_CEL_ERICSSON_NRU_S0301_CONFIG_LOG_OPTIONS_DEFAULT,
                      X86_64_CEL_ERICSSON_NRU_S0301_CONFIG_LOG_BITS_DEFAULT,
                      NULL, /* Custom log map */
                      X86_64_CEL_ERICSSON_NRU_S0301_CONFIG_LOG_CUSTOM_BITS_DEFAULT
                     );

