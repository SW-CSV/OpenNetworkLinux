/**************************************************************************//**
 *
 * x86_64_cel_dx032 Doxygen Header
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_DX032_DOX_H__
#define __X86_64_CEL_DX032_DOX_H__

/**
 * @defgroup x86_64_cel_dx032 x86_64_cel_dx032 - x86_64_cel_dx032 Description
 *

The documentation overview for this module should go here.

 *
 * @{
 *
 * @defgroup x86_64_cel_dx032-x86_64_cel_dx032 Public Interface
 * @defgroup x86_64_cel_dx032-config Compile Time Configuration
 * @defgroup x86_64_cel_dx032-porting Porting Macros
 *
 * @}
 *
 */

#endif /* __X86_64_CEL_DX032_DOX_H__ */
