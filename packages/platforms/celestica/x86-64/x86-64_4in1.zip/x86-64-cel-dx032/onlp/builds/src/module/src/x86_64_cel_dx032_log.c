/**************************************************************************//**
 *
 *
 *
 *****************************************************************************/
#include <x86_64_cel_dx032/x86_64_cel_dx032_config.h>

#include "x86_64_cel_dx032_log.h"
/*
 * x86_64_cel_dx032 log struct.
 */
AIM_LOG_STRUCT_DEFINE(
                      X86_64_CEL_DX032_CONFIG_LOG_OPTIONS_DEFAULT,
                      X86_64_CEL_DX032_CONFIG_LOG_BITS_DEFAULT,
                      NULL, /* Custom log map */
                      X86_64_CEL_DX032_CONFIG_LOG_CUSTOM_BITS_DEFAULT
                     );

