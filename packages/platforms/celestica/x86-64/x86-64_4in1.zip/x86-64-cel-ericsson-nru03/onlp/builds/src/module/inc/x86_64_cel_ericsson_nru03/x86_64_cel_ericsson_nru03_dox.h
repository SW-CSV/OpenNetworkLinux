/**************************************************************************//**
 *
 * x86_64_cel_ericsson_nru03 Doxygen Header
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_ERICSSON_NRU03_DOX_H__
#define __X86_64_CEL_ERICSSON_NRU03_DOX_H__

/**
 * @defgroup x86_64_cel_ericsson_nru03 x86_64_cel_ericsson_nru03 - x86_64_cel_ericsson_nru03 Description
 *

The documentation overview for this module should go here.

 *
 * @{
 *
 * @defgroup x86_64_cel_ericsson_nru03-x86_64_cel_ericsson_nru03 Public Interface
 * @defgroup x86_64_cel_ericsson_nru03-config Compile Time Configuration
 * @defgroup x86_64_cel_ericsson_nru03-porting Porting Macros
 *
 * @}
 *
 */

#endif /* __X86_64_CEL_ERICSSON_NRU03_DOX_H__ */
