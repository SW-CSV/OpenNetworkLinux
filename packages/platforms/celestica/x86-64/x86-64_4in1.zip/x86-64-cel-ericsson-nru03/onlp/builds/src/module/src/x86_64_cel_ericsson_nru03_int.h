/**************************************************************************//**
 *
 * x86_64_cel_ericsson_nru03 Internal Header
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_ERICSSON_NRU03_INT_H__
#define __X86_64_CEL_ERICSSON_NRU03_INT_H__

#include <x86_64_cel_ericsson_nru03/x86_64_cel_ericsson_nru03_config.h>

#endif /* __X86_64_CEL_ERICSSON_NRU03_INT_H__ */