/**************************************************************************//**
 *
 * 
 *
 *****************************************************************************/
#ifndef __X86_64_CEL_ERICSSON_NRU03_LOG_H__
#define __X86_64_CEL_ERICSSON_NRU03_LOG_H__

#define AIM_LOG_MODULE_NAME x86_64_cel_ericsson_nru03
#include <AIM/aim_log.h>

#endif /* __X86_64_CEL_ERICSSON_NRU03_LOG_H__ */
